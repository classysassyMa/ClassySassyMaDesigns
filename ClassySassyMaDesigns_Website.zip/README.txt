# ClassySassyMaDesigns Website

This is a free static storefront for ClassySassyMaDesigns.

## Publish it for free
1. Upload `index.html` and `style.css` to a static host such as GitHub Pages or Netlify.
2. No database or paid website builder is required.
3. The buttons send customers to Etsy for checkout.

## Updating products
Open `index.html` in a text editor and duplicate/edit a product card. Replace the Etsy listing URL, product name, price, and image URL.

The current storefront reflects the Etsy shop items visible on September 29, 2026.
